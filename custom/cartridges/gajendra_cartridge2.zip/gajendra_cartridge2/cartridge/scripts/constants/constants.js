exports.EN_US="en_US";
exports.FR_FR="fr_FR";