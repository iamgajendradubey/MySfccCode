var reCaptchaservice='UserRecatchaService';

module.exports={
    reCaptchaservice:reCaptchaservice,
}