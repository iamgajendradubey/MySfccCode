function OwnerName(params) {
    return params;

}
module.exports={
    OwnerName:OwnerName
}