tokenservice="accessTokenGenerateOcapi";
plpservice="GetAllproductsByOcapi";
loginservice="LoginByOcapi";
module.exports={
    tokenservice:tokenservice,
    plpservice:plpservice,
    loginservice:loginservice
}