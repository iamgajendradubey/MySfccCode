var storeLocatorService = 'storeLocatorTeam1';

module.exports ={
    storeLocatorService: storeLocatorService
}